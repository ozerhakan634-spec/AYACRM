# CRM Sistemi - Veritabanı Kurulumu

Bu CRM sistemi Supabase (PostgreSQL) veritabanı kullanmaktadır.

## 🚀 Hızlı Başlangıç

### 1. Supabase Projesi Oluşturma

1. [Supabase](https://supabase.com) sitesine gidin ve hesap oluşturun
2. Yeni proje oluşturun
3. Proje URL'sini ve anonim anahtarını not alın

### 2. Environment Variables

Proje kök dizininde `.env.local` dosyası oluşturun:

```bash
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Veritabanı Şeması

`database/schema.sql` dosyasındaki SQL komutlarını Supabase SQL Editor'da çalıştırın.

### 4. Bağımlılıkları Yükleyin

```bash
npm install
```

### 5. Uygulamayı Başlatın

```bash
npm run dev
```

## 📊 Veritabanı Yapısı

### Tablolar

- **clients** - Müşteri bilgileri
- **consultants** - Danışman bilgileri  
- **documents** - Doküman yönetimi
- **finance** - Finansal kayıtlar
- **calendar** - Takvim etkinlikleri
- **reports** - Raporlar

### İlişkiler

- Müşteriler danışmanlara atanabilir
- Dokümanlar müşteri ve danışmanlarla ilişkili
- Finansal kayıtlar müşteri ve danışmanlarla ilişkili
- Takvim etkinlikleri müşteri ve danışmanlarla ilişkili

## 🔧 Veritabanı Servisleri

`src/services/database.js` dosyasında tüm veritabanı işlemleri tanımlanmıştır:

- CRUD işlemleri (Create, Read, Update, Delete)
- İlişkisel veri sorguları
- Hata yönetimi

## 🎯 Özellikler

- ✅ Gerçek zamanlı veri senkronizasyonu
- ✅ Güvenli kimlik doğrulama
- ✅ Dosya yükleme desteği
- ✅ Gelişmiş arama ve filtreleme
- ✅ Excel export
- ✅ Responsive tasarım

## 🚨 Güvenlik

- Row Level Security (RLS) aktif
- API anahtarları environment variables'da saklanır
- Kullanıcı yetkilendirmesi
- SQL injection koruması

## 📝 Notlar

- Supabase ücretsiz planında aylık 500MB veri limiti vardır
- Production ortamında environment variables'ları güvenli şekilde yönetin
- Düzenli veri yedeklemesi yapın

## 🆘 Destek

Herhangi bir sorun yaşarsanız:
1. Console hatalarını kontrol edin
2. Supabase dashboard'da logları inceleyin
3. Network sekmesinde API çağrılarını kontrol edin
#   A Y A C R M  
 